This script allows tasks to be exported from Outlook in a format suitable for 
importing into Google Tasks using the Google Tasks Import web app at 
http://import-tasks.appspot.com

The major difference between the export file created by this script and the
standard Outlook export file, is that the exported file;
- supports international characters by using UTF-8 
  (as required when importing into Google Tasks), and
- uses an unambiguous date format, and
- has the columns required by Import Tasks.

For instructions on installing and using the script, please refer to
http://import-tasks.appspot.com/static/instructions_import_from_outlook.html
